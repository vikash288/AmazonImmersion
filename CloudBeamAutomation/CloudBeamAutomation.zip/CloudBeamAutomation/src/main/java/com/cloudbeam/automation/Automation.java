package com.cloudbeam.automation;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Automation
 */
public class Automation extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Automation() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("This page is for ATTUNITY CloudBeam Automation").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		
		PrintWriter out = response.getWriter();
		String taskname = request.getParameter("taskname").toString();
		
		Runtime runtime = Runtime.getRuntime();
		Process processsstop = runtime.exec("C:\\Program Files\\Attunity\\Replicate\\bin\\repctl connect; stoptask "+taskname+"; disconnect");
	    Process processsstart = runtime.exec("C:\\Program Files\\Attunity\\Replicate\\bin\\repctl connect; execute "+taskname+" 3 Flags=1; disconnect");
		OutputStream output = processsstart.getOutputStream();
		BufferedReader br = new BufferedReader(new InputStreamReader(processsstart.getInputStream()));		
		String processString = "";		
		while((processString = br.readLine()) != null) {			
			
			processString =processString+"\t"+ br.readLine();		
			
		}
		out.println(processString);
	}

}
